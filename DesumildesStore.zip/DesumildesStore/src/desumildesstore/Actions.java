package desumildesstore;

import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Actions {
    
    public void escrever(Cliente cliente){
        FileWriter escrever;
        try {
            escrever = new FileWriter("meusclientes.txt", true);
             BufferedWriter escv = new BufferedWriter(escrever);
             escv.write(cliente.getUser()+"#"+cliente.getSenha()+"\n");
             escv.flush();
        } catch (IOException ex) {
            Logger.getLogger(Actions.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
