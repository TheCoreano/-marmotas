package desumildesstore;
public class Computador extends Produto {
    
    private int estoque, vendido;
    private boolean disponivel;

    public Computador(){
        
    }
    
    public Computador(int estoque, int vendido, boolean disponivel) {
        this.estoque = estoque;
        this.vendido = vendido;
        this.disponivel = disponivel;
    } 

    public int getEstoque() {
        return estoque;
    }

    public void setEstoque(int estoque) {
        this.estoque = estoque;
    }

    public int getVendido() {
        return vendido;
    }

    public void setVendido(int vendido) {
        this.vendido = vendido;
    }

    public boolean isDisponivel() {
        return disponivel;
    }

    public void setDisponivel(boolean disponivel) {
        this.disponivel = disponivel;
    }
    
    
}
