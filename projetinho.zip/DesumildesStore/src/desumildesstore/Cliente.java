package desumildesstore;
public class Cliente {
    
    private String user,senha;
    private int dinheiro;
    
     public Cliente(){
        
    }
    
    public Cliente(String user, String senha, int dinheiro){
        this.user = user;
        this.senha = senha;
        this.dinheiro = dinheiro;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
    
    public int getDinheiro() {
        return dinheiro;
    }

    public void setDinheiro(int dinheiro) {
        this.dinheiro = dinheiro;
    }
    
}

