package desumildesstore;
public class DesumildesStore {
 public static void main(String[] args) {
        
     JanelaPrincipal main = new JanelaPrincipal();
     main.setVisible(true);
     main.setSize(500,500);
     main.setTitle("Desumildes Store - 2016");
     main.setLocationRelativeTo(null);
    }
}
