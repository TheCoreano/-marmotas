package desumildesstore;

import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Actions {
    
    public void escrever(Cliente cliente){
        FileWriter escrever;
        try {
            escrever = new FileWriter("meusclientes.txt", true);
             BufferedWriter escv = new BufferedWriter(escrever);
             escv.write(cliente.getUser()+ "#" +cliente.getSenha()+ "\n");
             escv.flush();
        } catch (IOException ex) {
            Logger.getLogger(Actions.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void ler(List<Cliente> meusClientes){
        try {
        FileReader arq = new FileReader("meusclientes.txt");
        BufferedReader lerArq = new BufferedReader(arq);
        String s = "";
        while((s = lerArq.readLine()) != null){
	String fields[] = s.split("#");
	String user = fields[0];
        String senha = fields[1];
	Cliente c1 = new Cliente(user,senha);
        meusClientes.add(c1);
	}
        arq.close();
    } catch (IOException e) {
        System.err.printf("Erro na abertura do arquivo: %s.\n",
          e.getMessage());
        }
    }
    
     public void escreverProduto(Produto produto){
        FileWriter escrever;
        try {
            escrever = new FileWriter("meusprodutos.txt", true);
             BufferedWriter escv = new BufferedWriter(escrever);
             escv.write(produto.getNome()+ " " + produto.getPreço()+ "\n");
             escv.flush();
        } catch (IOException ex) {
            Logger.getLogger(Actions.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void Produto(List<Produto> meusProdutos){
        try {
        FileReader arq = new FileReader("meusprodutos.txt");
        BufferedReader lerArq = new BufferedReader(arq);
        String s = "";
        while((s = lerArq.readLine()) != null){
	String fields[] = s.split(" ");
	String nome = fields[0];
        int money = Integer.parseInt(fields[1]);
	Produto p1 = new Produto(nome,money);
        meusProdutos.add(p1);
	}
        arq.close();
        } catch (IOException e) {
            System.err.printf("Erro na abertura do arquivo: %s.\n",
              e.getMessage());
            }
    }
}
